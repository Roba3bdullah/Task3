function draw(){
        var canvas = document.getElementById('myCanvas');
        var context = canvas.getContext('2d');
        var x1 = document.getElementById("r").value;
        var x2 = document.getElementById("f").value;
        var y1 = document.getElementById("l").value;

        context.beginPath();
        context.moveTo(0,x1);
        context.lineTo(x1,x2);
        context.lineTo(x2,y2);


        context.stroke();
    }
