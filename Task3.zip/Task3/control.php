<!DOCTYPE html>
<html>
<meta charset = "utf-8">

<head>
    <title> Robot Control </title>



</head>
<body style="background-color: #DCDCDC">

  <form method="POST">


    <h2 align = "center" ><font color ="black">  Audio Control </h2>

<div font size = 6px; align = "center" >
  Right : <input type='number' name='r'>
  <br>
    <br>

  Forwards : <input type='number' name='f'>
  <br>
    <br>

  Left : <input type='number' name='l'>
  <br>
  <br>
 <input type='submit' name='save' value="Save">
  <input type='submit' name='delet' value="Delete">
      <input type='submit' name='start' value="Start">
</div>

    <h1>


      <?php

    $servername = "localhost";
    $username = "Roba";
    $password = "1234";
    $db = "auto_con";

    $conn = new mysqli($servername, $username, $password, $db);



    ?>
   <center>
      <?php

    if (isset($_POST['save'])){
    $right=$_POST['r'];
    $forwards=$_POST['f'];
    $left=$_POST['l'];
    $iquery = "INSERT INTO control(R , F , L) VALUES ('".$right."' , '".$forwards."' ,'".$left."' )";
    $q=mysqli_query($conn,$iquery);

    if ($q){
      echo " <h5 ><font size = 4;> <font color = #3CB371> OK , Data storded !</h5>";
    } else {
      echo "<h6 ><font size = 4;> <font color = #800000> NOT OK , Data not storded!</h6>";
    }
    }
?>

<?php


     if (isset($_POST['delet'])){
       $del= "DELETE FROM control";
       $q=mysqli_query($conn,$del);
       }
?>

<h3 font size = 6px; align = "center" >
<?php
     if (isset($_POST['start'])){

       $iquery = "SELECT * FROM control";
       $result=mysqli_query($conn,$iquery);
       while ($row=mysqli_fetch_array($result)){

         echo "<font size = 3;>Right: ", $row['R'] , "<h>&#x2190;</h>" , "  , Forwards:  " , $row['F'] ,"<h>&uarr;</h>" , "   , Left: " . $row['L'] , "<h>&rarr;</h>";
         echo " <br/>";

  


       }


    }




    mysqli_close($conn);


     ?>









</form>
</center>
</body>
</html>
