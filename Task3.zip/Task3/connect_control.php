<!DOCTYPE html>
<html>
<meta charset = "utf-8">

<head>
    <title> Connection </title>
</head>
<body style="background-color: #DCDCDC">



</body>
</html>

<?php

$servername = "localhost";
$username = "Roba";
$password = "1234";
$db = "auto_con";

$conn = new mysqli($servername, $username, $password, $db);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";


if (isset($_POST['save'])){
$right=$_POST['r'];
$forwards=$_POST['f'];
$left=$_POST['l'];
$iquery = "INSERT INTO control(R , F , L) VALUES ('".$right."' , '".$forwards."' ,'".$left."' )";
$q=mysqli_query($conn,$iquery);

if ($q){
  echo "OK , Data storded!";
} else {
  echo "NOT OK , Data not storded!";
}
}


 if (isset($_POST['delet'])){
   $del= "DELETE FROM control";
   $q=mysqli_query($conn,$del);
   }

 if (isset($_POST['start'])){

   $iquery = "SELECT * FROM control";
   $result=mysqli_query($conn,$iquery);
   while ($row=mysqli_fetch_array($result)){

     echo "Right", $row['R'] , "Forwards" , $row['F'] , "Left" . $row['L'];
   }

}

mysqli_close($conn);

 ?>
